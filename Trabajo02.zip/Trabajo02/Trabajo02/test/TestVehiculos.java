package test;

import java.util.ArrayList;
import java.util.List;

import entities.Vehiculo;
import utils.ConsultaLista;

public class TestVehiculos {
    public static void main(String[] args) {
        List<Vehiculo> vehiculos = new ArrayList();

        System.out.println(" ");
        ConsultaLista object = new ConsultaLista();
        object.obtenerLista(vehiculos);
        object.recorrerLista(vehiculos);

        System.out.println("=====================================================");

        object.vehiculoMasCaro(vehiculos);
        object.vehiculoMasBarato(vehiculos);
        object.obtenerModeloLetraY(vehiculos, "Y");

        System.out.println("======================================================");

        object.precioMayorMenor(vehiculos);

        System.out.println("=======================================================");

        object.ordenNatural(vehiculos);
    }
}
