package utils;

import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.List;

import entities.Auto;
import entities.Moto;
import entities.Vehiculo;
import interfaces.I_Consulta;

public class ConsultaLista implements I_Consulta{

    @Override
    public List obtenerLista(List<Vehiculo> vehiculos) {
        vehiculos.add(new Auto("Peugeot","206", "4", 200000.00));
        vehiculos.add(new Moto("Honda","Titan", "125c", 60000.00));
        vehiculos.add(new Auto("Peugeot","208", "5", 250000.00));
        vehiculos.add(new Moto("Yamaha","YBR", "160c", 80500.50));
        return vehiculos;
        }

        /*
            Método para recorrer lista
        */
    @Override
    public void recorrerLista(List<Vehiculo> lista) {
        lista.forEach(System.out::println);
    }


    /* Método para obtener marca, modelo del vehiculo mas caro */
    @Override
    public void vehiculoMasCaro(List<Vehiculo> lista) {
        double precioMax = lista
                        .stream()
                        .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                        .get()
                        .getPrecio();
                lista
                        .stream()
                        .filter(vehiculo -> vehiculo
                                .getPrecio() == precioMax)
                        .forEach(vehiculo -> System.out
                                .println("Vehículo más caro: " + vehiculo.getMarca() + " "
                                                + vehiculo.getModelo()));
    }


    /* Método para obtener marca y modelo del vehiculo mas barato */
    @Override
    public void vehiculoMasBarato(List<Vehiculo> lista) {
        double precioMax = lista
                        .stream()
                        .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                        .get()
                        .getPrecio();
                lista
                        .stream()
                        .filter(vehiculo -> vehiculo
                                .getPrecio() == precioMax)
                        .forEach(vehiculo -> System.out
                                .println("Vehículo más barato: " + vehiculo.getMarca() + " "
                                                + vehiculo.getModelo()));
    }


    /* Método para obtener marca, modelo y precio de vehiculo con la letra "Y" en modelo */
    @Override
    public void obtenerModeloLetraY(List<Vehiculo> lista, String x) {
        DecimalFormat df = new DecimalFormat("###,###.00");
                lista
                        .stream()
                        .filter(vehiculo -> vehiculo
                                .getModelo()
                                .toUpperCase()
                                .contains(x))
                        .forEach(vehiculo -> System.out
                                .println("Vehículo que contiene en el modelo la letra\"" + x + "\": "
                                        + vehiculo.getMarca() + " " + vehiculo.getModelo() + " "
                                        + df.format(vehiculo.getPrecio())));
    }


    /* Método para ordenar de mayor precio a menor precio */
    @Override
    public void precioMayorMenor(List<Vehiculo> lista) {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
                lista
                        .stream()
                        .sorted(Comparator.comparingDouble(Vehiculo::getPrecio)
                                .reversed())
                        .forEach(vehiculo -> System.out
                                .println(vehiculo.getMarca() + " " + vehiculo.getModelo()));
    }


    /* Método para ordenar en forma natural */
    public void ordenNatural(List<Vehiculo> lista) {
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
                lista
                        .stream()
                        .sorted()
                        .forEach(System.out::println);
    }
}
