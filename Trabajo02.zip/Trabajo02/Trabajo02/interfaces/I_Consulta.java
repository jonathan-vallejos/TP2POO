package interfaces;

import java.util.List;

import entities.Vehiculo;

public interface I_Consulta {

    public List obtenerLista(List<Vehiculo> lista);
    
    public void recorrerLista(List<Vehiculo> lista);
    
    public void vehiculoMasCaro(List<Vehiculo> lista);
    
    public void vehiculoMasBarato(List<Vehiculo> lista);

    public void obtenerModeloLetraY(List<Vehiculo> lista, String x);

    public void precioMayorMenor(List<Vehiculo> lista);

    public void ordenNatural(List<Vehiculo> lista);

}
